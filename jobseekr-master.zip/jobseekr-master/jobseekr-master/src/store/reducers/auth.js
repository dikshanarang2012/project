import * as actionTypes from "../actions/actiontypes";

const initialState = {
  isAuthenticated: false,
  token: "",
  savedJobs: [],
  admin: false,
  jobs:[],
  savedJobs:[]
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.IS_AUTHENTICATED:
      return {
        ...state,
        isAuthenticated: action.authState,
        token: action.token,
      };
      break;

    case actionTypes.SAVE_JOBS:
      return {
        ...state,
        savedJobs: action.savedJobs,
      };
      break;

    case actionTypes.IS_ADMIN:
      return {
        ...state,
        admin: action.adminState

      }

      case actionTypes.GET_JOBS:
        return {
          ...state,
          jobs: action.jobs
  
        }

        case actionTypes.LOGGED_IN_USER:
        return {
          ...state,
          user: action.user
  
        }

    default:
      return state;
      break;
  }
};

export default authReducer;
