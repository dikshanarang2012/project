import Axios from 'axios';
import * as actionTypes from './actiontypes';

export const isAuthenticatedHandler = (authState,token) => {
    return {
        type: actionTypes.IS_AUTHENTICATED,
        authState:authState,
        token:token
    }
}

export const saveJOBS = (job) => {
    return {
        type: actionTypes.SAVE_JOBS,
        savedJobs:job,
    }
}

export const STOREjOBS = (jobs) => {
    return {
        type: actionTypes.GET_JOBS,
        jobs:jobs,
    }
}


export const getJobs = (jobs) => {
    return  {
        type:actionTypes.GET_JOBS,
        jobs:jobs,
    }
}

export const isAdmin = (adminState) => {
    return {
        type:actionTypes.IS_ADMIN,
        adminState: adminState
    }
}


export const loggedInUser = (user) => {
    return {
        type:actionTypes.LOGGED_IN_USER,
        user: user
    }
}