export const LOGGED_IN_USER = 'LOGGED_IN_USER';
export const IS_AUTHENTICATED = 'IS_AUTHENTICATED';
export const SAVE_JOBS = 'SAVE_JOBS';
export const GET_JOBS = 'GET_JOBS';
export const IS_ADMIN = 'IS_ADMIN';