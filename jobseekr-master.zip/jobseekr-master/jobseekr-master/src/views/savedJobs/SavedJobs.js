import React, { useEffect } from "react";
import { connect } from "react-redux";
import JobPost from "../../components/JobPost/JobPost";
import Axios from 'axios';
import * as actions from '../../store/actions/index';

function SavedJobs(props) {

  useEffect(() => {
    Axios.get('http://localhost:3000/savedjobs')
      .then(response => {
        props.saveJOBS(response.data)
      })
  }, []);

  return (
    <div className="container mt-5 post__container">
      <h4 className="mb-4">Saved Jobs</h4>

      {props.savedJobs.map((saved, index) => (
        <JobPost
          key={index}
          title={saved.title}
          company={saved.company}
          date={saved.date}
          bio={saved.bio}
          lastUpdate={saved.lastUpdate}
        />
      ))}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    savedJobs: state.auth.savedJobs,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveJOBS: (job) => dispatch(actions.saveJOBS(job)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SavedJobs);
