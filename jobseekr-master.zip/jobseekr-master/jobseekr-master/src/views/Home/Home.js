import React, { useEffect } from "react";
import { connect } from "react-redux";
import JobPost from "../../components/JobPost/JobPost";
import'./Home.css';
import * as actions from '../../store/actions/index';
import Axios from 'axios';

function Home(props) {
  useEffect(() => {
    Axios.get('http://localhost:3000/jobs')
      .then(response => {
        props.getJobsHandler(response.data)
      })
  }, []);
  return (
    <div>
      <section className="jumbotron text-center">
        <div className="container">
          <h1 className="jumbotron-heading">Job Search</h1>
          <div className="row justify-content-center mt-5">
            <input type="text" placeholder="Skills" />
            <input className="ml-2" type="text" placeholder="Location" />
            <button className="btn btn-primary ml-2">Find Jobs</button>
          </div>
        </div>
      </section>
      <div className="row job__Section">
      {
          props.jobs.length > 0 && props.jobs.map((post, index) => {
            return <JobPost
              key={index}
              title={post.jobTitle}
              company={post.companyName}
              date={post.createdAt}
              responsibility={post.responsibility}
              role={post.role}
              id={post._id}
            />
          })
        }

  
        
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    savedJobs: state.auth.savedJobs,
    jobs: state.auth.jobs
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getJobsHandler: (jobs) =>
      dispatch(actions.getJobs(jobs)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)
    (Home);


