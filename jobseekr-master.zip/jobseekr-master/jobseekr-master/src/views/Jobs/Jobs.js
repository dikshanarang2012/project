import React, { useEffect, useState } from "react";
import JobPost from "../../components/JobPost/JobPost";
import "./Jobs.css";
import { connect } from "react-redux";
import * as actions from '../../store/actions/index'


function Jobs(props) {

  const [posts, setPosts] = useState([]);



  return (
    <React.Fragment>
      <div class="container post__container mt-5">
        <h4 className="mb-4">JOBS</h4>
        {
          props.jobs.length > 0 && props.jobs.map((post, index) => {
            console.log(post)
            return <JobPost
              key={index}
              title={post.jobTitle}
              company={post.companyName}
              date={post.createdAt}
              responsibility={post.responsibility}
              role={post.role}
              id={post._id}
            />
          })
        }

      </div>
    </React.Fragment>
  );
}

const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    savedJobs: state.auth.savedJobs,
    jobs: state.auth.jobs
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getJobsHandler: (jobs) =>
      dispatch(actions.getJobs(jobs)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)
    (Jobs);
